package com.example.camp_leader

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
