import 'package:flutter/material.dart';

/// Application color palette.
class AppColors {
  /// Primary brand color used for theming.
  static const Color primary = Colors.green;
}
